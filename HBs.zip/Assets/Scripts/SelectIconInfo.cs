using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectIconInfo : MonoBehaviour
{
    public int xPos;
    public int yPos;
    public string characterID;
}
