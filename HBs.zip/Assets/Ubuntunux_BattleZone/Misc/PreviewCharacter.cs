using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PreviewCharacter : MonoBehaviour
{
    public string Name;
    public Sprite Annoying;
    public Sprite Groggy;
    public Sprite Hit;
    public Sprite Win;
    public Sprite Lose;
    public Sprite Attack0;
    public Sprite Attack1;
    public Sprite Attack2;
    public Sprite Portrait;
    public Sprite PortraitLose;    
    public Sprite Stand;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
